﻿#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

FILE* totfile;
const char ecnfile[] = "enc__.m4a";
int shift = 23;

void encode(char chr)
{
	putc(chr + shift, totfile);

}
void decode(char chr)
{
	putc(chr - shift, totfile);
}

int main()
{
	FILE* file = fopen("enc.m4a","rb");
	totfile = fopen(ecnfile,"wb");
	char curr_char = ' ';
	while (1)
		if (!feof(file))
		{
			curr_char = getc(file);
			printf("%c", curr_char);
			decode(curr_char);
		}
		else
			break;

	fclose(file);
	fclose(totfile);
	return 0;
		
}
